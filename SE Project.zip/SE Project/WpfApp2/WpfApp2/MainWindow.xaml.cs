﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

// Work in progress
// Doesn't connect to database yet
// Need UI for retrieving records
namespace WpfApp2
{
    public partial class MainWindow : Window

    {
        public string firstNameInput;
        public string lastNameInput;
        public string areaInput = "";
        public bool lab = false;
        public bool frontDesk = false;
        public bool lounge = false;
        public SubmittedRecord record;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Area checkboxes
        private void Unchecked(object sender, RoutedEventArgs e)
        {
            //System.Collections.Generic.IEnumerable<System.Windows.Controls.CheckBox> checkboxes = MainCanvas.Children.Cast<CheckBox>();

            CheckBox checkbox = (CheckBox)sender;

            if ((string)checkbox.Content == "Lab")
            {
                lab = true;
                if (areaInput.Length == 0)
                    areaInput += "lab";
                else
                    areaInput += ":lab";

            }

            else if ((string)checkbox.Content == "Front Desk")
            {
                frontDesk = true;
                if (areaInput.Length == 0)
                    areaInput += "frontDesk";
                else
                    areaInput += ":frontDesk";
            }

            else if ((string)checkbox.Content == "Lounge")
            {
                lounge = true;
                if (areaInput.Length == 0)
                    areaInput += "lounge";
                else
                    areaInput += ":lounge";
            }
        }


        // Submit button
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            string timeInput = DateTime.Now.ToString("h:mm tt");
            string dateInput = DateTime.Today.ToString("dd/MM/yyyy");

            record = new SubmittedRecord { firstName = firstNameInput, lastName=lastNameInput, time=timeInput, date=dateInput, area=areaInput};
            record.SubmitRecord();
        }

        // First Name textbox
        private void TextBox_FirstName(object sender, TextChangedEventArgs e)
        {
            TextBox firstNameTextBox = (TextBox)sender;
            firstNameInput = firstNameTextBox.Text;
            MessageBox.Show(firstNameInput);
        }

        // Last Name textbox
        private void TextBox_LastName(object sender, TextChangedEventArgs e)
        {
            TextBox lastNameTextBox = (TextBox)sender;
            lastNameInput = lastNameTextBox.Text;
            MessageBox.Show(lastNameInput);
        }
    }
}
