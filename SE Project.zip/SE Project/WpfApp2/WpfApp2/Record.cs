﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    public class Record
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string time { get; set; }
        public string date { get; set; }
        public string area { get; set; }
    }
}
