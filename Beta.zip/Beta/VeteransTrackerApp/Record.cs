﻿
/*
 * Steven Richter
 * UW Oshkosh
 * CS 341
 * Veteran's Department App
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VeteransTrackerApp
{
	public class Record
	{
		public string initials { get; set; }
		public string time { get; set; }
		public string date { get; set; }
		public string area { get; set; }
	}
}
