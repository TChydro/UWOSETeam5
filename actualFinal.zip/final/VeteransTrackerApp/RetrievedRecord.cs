﻿
/*
 * Steven Richter + Timothy Davis
 * UW Oshkosh
 * CS 341
 * Veteran's Department App
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace VeteransTrackerApp
{
    public class RetrievedRecord : Record
    {
        public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";

        // View contents of database
        public void view(string inInitials)
        {
            MySqlConnection conn = null;
            MySqlCommand command = null;
            MySqlDataReader reader = null;

            try
            {
                conn = new MySqlConnection(connectionString);
                conn.Open();

                string strCommand = "SELECT * FROM `Records` WHERE initials='" + inInitials + "'";

                command = new MySqlCommand(strCommand, conn);
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                reader = command.ExecuteReader();

                while (reader.Read())
                {

                    Object initials = reader.GetValue(0);
                    this.initials = initials.ToString();

                    Object time = reader.GetValue(1);
                    this.time = time.ToString();

                    Object date = reader.GetValue(2);
                    this.date = date.ToString();

                    Object area = reader.GetValue(3);
                    this.area = area.ToString();

                    MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
                }
            }

            catch
            {
                MessageBox.Show("Failed");
            }
        }

        //This section made by Timothy and Steven, Gets the data from the MySQL based on Date and exports if it contains the correct area
        public void viewer(string inDateS, string inArea)
        {
            bool lab = findArea(inArea, "lab");
            bool desk = findArea(inArea, "desk");
            bool lounge = findArea(inArea, "lounge");
            bool email = findArea(inArea, "email");
            bool phone = findArea(inArea, "phone");
            MySqlConnection conn = null;
            MySqlCommand command = null;
            MySqlDataReader reader = null;
            string item;
            List<string> items = new List<string>();

            try
            {
                conn = new MySqlConnection(connectionString);
                conn.Open();

                // Get all db entries
                string strCommand = "SELECT * FROM `Records`";
                command = new MySqlCommand(strCommand, conn);
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                reader = command.ExecuteReader();

                string month = inDateS[0].ToString() + inDateS[1].ToString();
                while (reader.Read())
                {
                    Object initials = reader.GetValue(0);
                    this.initials = initials.ToString();

                    Object time = reader.GetValue(1);
                    this.time = time.ToString();

                    Object date = reader.GetValue(2);
                    this.date = date.ToString();

                    Object area = reader.GetValue(3);
                    this.area = area.ToString();

                    if (!(this.date.Contains("/" + month + "/")))
                        continue;

                    lab = findArea(this.area, "lab");
                    desk = findArea(this.area, "desk");
                    lounge = findArea(this.area, "lounge");
                    email = findArea(this.area, "email");
                    phone = findArea(this.area, "phone");

                    if (inArea.Contains("Lab") && inArea.Contains("FrontDesk") && inArea.Contains("Lounge") && !(inArea.Contains("Email")) && !(inArea.Contains("Phone")))
                    {
                        inArea = "Lab : FrontDesk : Lounge ";
                    }

                    else if (inArea.Contains("Lab") && inArea.Contains("FrontDesk") && !(inArea.Contains("Lounge")))
                    {
                        inArea = "Lab : FrontDesk ";
                    }

                    else if (inArea.Contains("Lab") && inArea.Contains("Lounge") && !(inArea.Contains("FrontDesk")))
                    {
                        inArea = "Lab : Lounge ";
                    }

                    else if (inArea.Contains("FrontDesk") && inArea.Contains("Lounge") && !(inArea.Contains("Lab")))
                    {
                        inArea = "FrontDesk : Lounge ";
                    }

                    // When all areas are checked
                    if (inArea.Contains("Lab") && inArea.Contains("FrontDesk") && inArea.Contains("Lounge") && inArea.Contains("Email") && inArea.Contains("Phone"))
                    {
                        item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
                        items.Add(item);
                    }

                    // When email and phone are checked
                    else if (inArea.Equals("Email : Phone ") || inArea.Equals("Phone : Email "))
                    {
                        if (this.area.Equals("Phone ") || this.area.Equals("Email "))
                        {
                            item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
                            items.Add(item);
                        }

                    }

                    else if (this.area.Equals(inArea))
                    {
                        item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
                        items.Add(item);
                    }
                }
                export(items);
            }

            catch
            {
                MessageBox.Show("Failed");
            }
        }

        //This section made by Timothy and Steven, Checks if the area is in the requested area
        public bool findArea(string areas, string reqArea)
        {
            return areas.ToLower().Contains(reqArea);
        }

        //This section made by Timothy and Steven, Creates or appends a file with todays date for an excel sheet to look up.
        public void export(List<string> inItems)
        {
            string date = DateTime.Today.ToString("dd/MM/yyyy");
            date = date.Replace('/', '-');
            string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop).ToString();
            path += "\\" + date + ".csv";

            try
            {
                var file = File.Create(path);
                file.Close();
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            StringBuilder content = new StringBuilder();

            content.AppendLine("Initials,Time,Date,Area");
            foreach (string i in inItems)
            {
                content.AppendLine(i);
            }

            File.AppendAllText(path, content.ToString());
            MessageBox.Show("Downloaded entries.");

            return;
        }
    }
}
