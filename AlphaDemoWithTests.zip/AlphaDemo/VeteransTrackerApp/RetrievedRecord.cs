﻿
/*
 * Steven Richter + Timothy Davis
 * UW Oshkosh
 * CS 341
 * Veteran's Department App
 * 
 * Minor Edits by Nathan Moder for testing/error handling.
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace VeteransTrackerApp
{
	public class RetrievedRecord : Record
	{
		public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";

		public bool view(string inInitials)
		{
			MySqlConnection conn = null;
			MySqlCommand command = null;
			MySqlDataReader reader = null;

            //Added by Nathan Moder
            bool foundRecord = false;

            if (inInitials == null)
            {
                Console.WriteLine("Attempted to view a record will null information.");
                return false;
            }
            if (inInitials.Length == 0)
            {
                Console.WriteLine("Attempted to view a record that is empty.");
                return false;
            }
            //End Addition

            try
            {
				conn = new MySqlConnection(connectionString);
				conn.Open();

				string strCommand = "SELECT * FROM `Records` WHERE initials='" + inInitials + "'";

				command = new MySqlCommand(strCommand, conn);
				MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

				reader = command.ExecuteReader();

				while (reader.Read())
				{

					Object initials = reader.GetValue(0);
					this.initials = initials.ToString();

					Object time = reader.GetValue(1);
					this.time = time.ToString();

					Object date = reader.GetValue(2);
					this.date = date.ToString();

					Object area = reader.GetValue(3);
					this.area = area.ToString();

					MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
                    foundRecord = true;
				}
                //Added by Nathan Moder
                if (!foundRecord)
                    MessageBox.Show("Record does not exist.");
                //End Additions
                return foundRecord ;
			}

			catch
			{
				MessageBox.Show("Failed");
                return false;
			}
		}

		//This section made by Timothy, Gets the data from the MySQL based on Date and exports if it contains the correct area
		public bool viewer(string inDateS, string inDateE, string inArea)
		{
			bool lab = findArea(inArea, "lab");
			bool desk = findArea(inArea, "desk");
			bool lounge = findArea(inArea, "lounge");
			bool email = findArea(inArea, "email");
			bool phone = findArea(inArea, "phone");
			MySqlConnection conn = null;
			MySqlCommand command = null;
			MySqlDataReader reader = null;

            bool foundRecords = false;

            //Added by Nathan Moder
            String[] startDates = inDateS.Split('/');
            String[] endDates = inDateE.Split('/');
            int dayS = Convert.ToInt32(startDates[0]);
            int monthS = Convert.ToInt32(startDates[1]);
            int yearS = Convert.ToInt32(startDates[2]);

            int dayE = Convert.ToInt32(endDates[0]);
            int monthE = Convert.ToInt32(endDates[1]);
            int yearE = Convert.ToInt32(endDates[2]);

            if (yearS > yearE)
            {
                MessageBox.Show("Invalid date range. Bad years");
                return false;
            }

            if(monthS > monthE && yearS == yearE)
            {
                MessageBox.Show("Invalid date range. Bad Months");
                return false;
            }

            if (monthS > 12 || monthE > 12 || dayS > 31 || dayE > 31 || monthS < 1 || monthE < 1 || dayS < 1 || dayE < 1)
            {
                MessageBox.Show("Invalid date");
                return false;
            }
            //End Additions

            try
			{
				conn = new MySqlConnection(connectionString);
				conn.Open();

                // Get all db entries
                string strCommand = "SELECT * FROM `Records`";
                command = new MySqlCommand(strCommand, conn);
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                reader = command.ExecuteReader();

                while (reader.Read())
                {

                    Object initials = reader.GetValue(0);
                    this.initials = initials.ToString();

                    Object time = reader.GetValue(1);
                    this.time = time.ToString();

                    Object date = reader.GetValue(2);
                    this.date = date.ToString();

                    Object area = reader.GetValue(3);
                    this.area = area.ToString();
                    if (lab || desk || lounge || email || phone)
                    {
                        string item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
                        export(item);
                        foundRecords = true;
                    }

                    // MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
                }

                if (!foundRecords)
                    MessageBox.Show("Records do not exist.");
                else
                    MessageBox.Show("Successfully downloaded entries.");
                return foundRecords;

                //string i = inDateS;
                //while (i.Equals(inDateS))
                //{
                //	string strCommand = "SELECT * FROM `Records` WHERE date='" + i + "'";

                //	command = new MySqlCommand(strCommand, conn);
                //	MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

                //	reader = command.ExecuteReader();

                //	while (reader.Read())
                //	{

                //		Object initials = reader.GetValue(0);
                //		this.initials = initials.ToString();

                //		Object time = reader.GetValue(1);
                //		this.time = time.ToString();

                //		Object date = reader.GetValue(2);
                //		this.date = date.ToString();

                //		Object area = reader.GetValue(3);
                //		this.area = area.ToString();
                //		if (lab || desk || lounge || email || phone)
                //		{
                //			string item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
                //			export(item);
                //		}

                //		MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
                //	}
                //}
            }

            catch
			{
				MessageBox.Show("Failed");
                return false;
			}
		}

		//This section made by Timothy, Checks if the area is in the requested area
		public bool findArea(string areas, string reqArea)
		{
			 return areas.ToLower().Contains(reqArea);
		}

		//This section made by Timothy, Creates or appends a file with todays date for an excel sheet to look up.
		public void export(string inString)
		{
			// string date = DateTime.Today.ToString("mm/dd/yyyy");
			string path = @"c:\ProgramData\entries.csv";
            StringBuilder content = new StringBuilder();

            try
            {
                if (!(File.Exists(path)))
                {
                    var file = File.Create(path);
                    file.Close();
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            //StringBuilder content = new StringBuilder();

            // This is the entry content
            string info = inString;

            content.AppendLine("Entries");
            content.AppendLine(info);

            File.AppendAllText(path, content.ToString());


            return;

            //if (File.Exists(path))
            //{
            //	using (StreamWriter sw = File.AppendText(path))
            //	{
            //		sw.WriteLine(inString);
            //	}
            //}
            //else if(!File.Exists(path))
            //{
            //	using (StreamWriter sw = File.CreateText(path))
            //	{
            //		sw.WriteLine(inString);
            //	}
            //}
        }
	}
}
