﻿/*
 * Timothy Davis + Steven Richter
 * UW Oshkosh
 * CS 341
 * Veterans Department App
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace VeteransTrackerApp
{

	public partial class DownloadData : Window
	{
		public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";
		public string initialsInput = "";
		public string areaInput = "";
		public bool lab = false;
		public bool frontDesk = false;
		public bool lounge = false;
		public bool email = false;
		public bool phone = false;
		public SubmittedRecord submittedRecord;
		public RetrievedRecord retrievedRecord;
        public string startMonthInput;
        public string endMonthInput;
        public string startYearInput;
        public string endYearInput;
        public string startDateInput;
        public string endDateInput;
		public DateTime startDate;
		public DateTime endDate;

		public DownloadData()
		{
			InitializeComponent();
		}

		private void Check(object sender, RoutedEventArgs e)
		{
			CheckBox check = (CheckBox)sender;

			if ((string)check.Content == "Lab")
			{
				lab = true;
				if (areaInput.Length == 0)
					areaInput += "Lab ";
				else
					areaInput += ": Lab ";

			}

			else if ((string)check.Content == "Front Desk")
			{
				frontDesk = true;
				if (areaInput.Length == 0)
					areaInput += "FrontDesk ";
				else
					areaInput += ": FrontDesk ";
			}

			else if ((string)check.Content == "Lounge")
			{
				lounge = true;
				if (areaInput.Length == 0)
					areaInput += "Lounge ";
				else
					areaInput += ": Lounge ";
			}

			else if ((string)check.Content == "Email")
			{
				frontDesk = true;
				if (areaInput.Length == 0)
					areaInput += "Email ";
				else
					areaInput += ": Email ";
			}

			else if ((string)check.Content == "Phone")
			{
				lounge = true;
				if (areaInput.Length == 0)
					areaInput += "Phone ";
				else
					areaInput += ": Phone ";
			}
		}

		private void Dates()
		{
			startDate = new DateTime();
			endDate = new DateTime();

			startDate = Convert.ToDateTime(startMonthInput + "/" + "01/" + startYearInput);
			endDate = Convert.ToDateTime(endMonthInput + "/" + "30/" + endYearInput);

			startDateInput = startDate.Month + "/" + startDate.Day + "/" + startDate.Year;
			endDateInput = endDate.Month + "/" + endDate.Day + "/" + endDate.Year;
		}

		private void Gather(object sender, RoutedEventArgs e)
		{
			Button button = (Button)sender;

			Dates();

			retrievedRecord = new RetrievedRecord { };
			if (initialsInput.Length < 1)
				initialsInput = "Test";

			retrievedRecord.viewer(startDateInput, endDateInput, this.areaInput);
		}

        private void StartMonth_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox startMonthTextbox = (TextBox)sender;
            startMonthInput = startMonthTextbox.Text;
        }

        private void EndMonth_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox endMonthTextbox = (TextBox)sender;
            endMonthInput = endMonthTextbox.Text;
        }

        private void StartYear_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox startYearTextbox = (TextBox)sender;
            startYearInput = startYearTextbox.Text;
        }

        private void EndYear_TextChanged(object sender, TextChangedEventArgs e)
        {
            TextBox endYearTextbox = (TextBox)sender;
            endYearInput = endYearTextbox.Text;
        }
    }
}
