﻿
/*
 * Steven Richter
 * UW Oshkosh
 * CS 341
 * Veteran's Department App
 * 
 * Minor Edits by Nathan Moder for testing/error handling.
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;


namespace VeteransTrackerApp
{
	public class SubmittedRecord : Record
	{
		public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";

        private static int MAX_LENGTH = 50;

        public bool SubmitRecord()
		{
			MySqlConnection conn = null;
			MySqlCommand command = null;
			MySqlDataReader reader = null;

            //Added by Nathan Moder
            if (this.initials == null || this.time == null || this.date == null || this.area == null)
            {
                Console.WriteLine("Attempted to submit a record will null information.");
                return false;
            }
            if (this.initials.Length == 0 || this.time.Length == 0 || this.date.Length == 0 || this.area.Length == 0)
            {
                Console.WriteLine("Attempted to submit a record that is empty.");
                return false;
            }
            if (this.initials.Length > MAX_LENGTH || this.time.Length > MAX_LENGTH || this.date.Length > MAX_LENGTH || this.area.Length > MAX_LENGTH)
            {
                Console.WriteLine("Attempted to submit a record that is too big for the database to hold");
                return false;
            }
            //End Addition

            try
            {
				conn = new MySqlConnection(connectionString);
				conn.Open();

				string strCommand = "INSERT INTO `Records`(`initials`, `inTime`, `date`, `area`) VALUES('" + this.initials + "','" + this.time + "','" + this.date + "','" + this.area + "')";
				//string strCommand = "INSERT INTO `Records`(`firstName`, `lastName`, `inTime`, `date`, `area`) VALUES('Steven', 'Richter', '10:50AM', '11/6/2018', 'Lounge')";

				command = new MySqlCommand(strCommand, conn);
				MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

				reader = command.ExecuteReader();

				while (reader.Read())
				{
					Object thing = reader.GetValue(0);
					MessageBox.Show(thing.ToString());
				}

                return true;
			}
			catch
			{
				MessageBox.Show("Failed");
                return false;
			}
		}

	}
}
