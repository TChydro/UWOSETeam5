﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using VeteransTrackerApp;


namespace TestSuite
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestSubmitNoInfo()
        {
            SubmittedRecord emptyRecord = new SubmittedRecord();
            emptyRecord.initials = "";
            emptyRecord.time = "";
            emptyRecord.date = "";
            emptyRecord.area = "";

            bool wasSubmitted;
            wasSubmitted = emptyRecord.SubmitRecord();
            Assert.AreEqual(wasSubmitted, false);
        }

        [TestMethod]
        public void TestSubmitNullInfo()
        {
            SubmittedRecord nullRecord = new SubmittedRecord();

            bool wasSubmitted;
            wasSubmitted = nullRecord.SubmitRecord();
            Assert.AreEqual(wasSubmitted, false);
        }

        [TestMethod]
        public void TestSubmitTooBig()
        {
            SubmittedRecord bigRecord = new SubmittedRecord();
            String bigString = "a";
            int i;
            int maxSize = 50;

            for (i = 0; i < maxSize; i++)
            {
                bigString = bigString + "aaaaa";
            }

            bigRecord.area = bigString;
            bigRecord.date = bigString;
            bigRecord.time = bigString;
            bigRecord.initials = bigString;

            bool wasSubmitted;
            wasSubmitted = bigRecord.SubmitRecord();
            Assert.AreEqual(wasSubmitted, false);
        }

        [TestMethod]
        public void TestSubmitGood()
        {
            SubmittedRecord goodRecord = new SubmittedRecord();
            goodRecord.initials = "TestRecordPleaseIgnore";
            goodRecord.area = "TestRecordPleaseIgnore";
            goodRecord.date = "4/20/1669";
            goodRecord.time = "4:20 PM";

            bool wasSubmitted;
            wasSubmitted = goodRecord.SubmitRecord();
            Assert.AreEqual(wasSubmitted, true);
        }

        [TestMethod]
        public void TestViewGood()
        {
            RetrievedRecord goodRecord = new RetrievedRecord();
            goodRecord.initials = "TestRecordPleaseIgnore!";
            goodRecord.area = "TestRecordPleaseIgnore";
            goodRecord.date = "4/20/1969";
            goodRecord.time = "4:20 PM";

            bool wasRetreived;
            wasRetreived = goodRecord.view(goodRecord.initials);
            Assert.AreEqual(wasRetreived, true);
        }

        [TestMethod]
        public void TestViewEmpty()
        {
            RetrievedRecord emptyRecord = new RetrievedRecord();
            emptyRecord.initials = "";
            emptyRecord.area = "";
            emptyRecord.date = "";
            emptyRecord.time = "";

            bool wasRetreived;
            wasRetreived = emptyRecord.view(emptyRecord.initials);
            Assert.AreEqual(wasRetreived, false);
        }

        [TestMethod]
        public void TestViewNull()
        {
            RetrievedRecord nullRecord = new RetrievedRecord();

            bool wasRetreived;
            wasRetreived = nullRecord.view(nullRecord.initials);
            Assert.AreEqual(wasRetreived, false);
        }

        [TestMethod]
        public void TestViewDNE()
        {
            RetrievedRecord DNERecord = new RetrievedRecord();

            DNERecord.initials = "DoesNotExist";
            DNERecord.area = "DoesNotExist";
            DNERecord.date = "DoesNotExist";
            DNERecord.time = "DoesNotExist";

            bool wasRetreived;
            wasRetreived = DNERecord.view(DNERecord.initials);
            Assert.AreEqual(wasRetreived, false);
        }

        [TestMethod]
        public void TestBulkViewExists()
        {
            RetrievedRecord goodRecord = new RetrievedRecord();
           
            bool wasRetreived;
            wasRetreived = goodRecord.viewer("01/11/2018", "30/11/2018", "Phone");
            Assert.AreEqual(wasRetreived, true);
        }

        [TestMethod]
        public void TestBulkViewBadRange()
        {
            RetrievedRecord badRangeRecord = new RetrievedRecord();

            bool wasRetreived;
            wasRetreived = badRangeRecord.viewer("01/12/2018", "30/11/2018", "Phone");
            Assert.AreEqual(wasRetreived, false);
        }

        [TestMethod]
        public void TestBulkViewBadDates()
        {
            RetrievedRecord badDatesRecord = new RetrievedRecord();

            bool wasRetreived;
            wasRetreived = badDatesRecord.viewer("32/13/2018", "45/15/2019", "Phone");
            Assert.AreEqual(wasRetreived, false);
        }

        [TestMethod]
        public void TestBulkViewNoRecords()
        {
            RetrievedRecord noRecords = new RetrievedRecord();

            bool wasRetreived;
            wasRetreived = noRecords.viewer("01/11/1930", "31/11/1930", "Phone");
            Assert.AreEqual(wasRetreived, false);
        }
    }

}
