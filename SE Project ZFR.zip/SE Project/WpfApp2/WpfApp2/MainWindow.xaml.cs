﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

// Work in progress
// Doesn't connect to database yet
// Need UI for retrieving records
namespace WpfApp2
{
    public partial class MainWindow : Window
    {
        public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";
        public string firstNameInput;
        public string lastNameInput;
        public string areaInput = "";
        public bool lab = false;
        public bool frontDesk = false;
        public bool lounge = false;
        public SubmittedRecord submittedRecord;
        public RetrievedRecord retrievedRecord;

        public MainWindow()
        {
            InitializeComponent();
        }

        // Area checkboxes
        private void Unchecked(object sender, RoutedEventArgs e)
        {
            //System.Collections.Generic.IEnumerable<System.Windows.Controls.CheckBox> checkboxes = MainCanvas.Children.Cast<CheckBox>();

            CheckBox checkbox = (CheckBox)sender;

            if ((string)checkbox.Content == "Lab")
            {
                lab = true;
                if (areaInput.Length == 0)
                    areaInput += "Lab ";
                else
                    areaInput += ": Lab ";

            }

            else if ((string)checkbox.Content == "Front Desk")
            {
                frontDesk = true;
                if (areaInput.Length == 0)
                    areaInput += "FrontDesk ";
                else
                    areaInput += ": FrontDesk ";
            }

            else if ((string)checkbox.Content == "Lounge")
            {
                lounge = true;
                if (areaInput.Length == 0)
                    areaInput += "Lounge ";
                else
                    areaInput += ": Lounge ";
            }
        }


        // Submit button
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            string timeInput = DateTime.Now.ToString("h:mm tt");
            string dateInput = DateTime.Today.ToString("dd/MM/yyyy");

            submittedRecord = new SubmittedRecord { firstName = firstNameInput, lastName=lastNameInput, time=timeInput, date=dateInput, area=areaInput};
            submittedRecord.SubmitRecord();
        }

        // Get Entry button
        private void GetDBEntry(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;

            retrievedRecord = new RetrievedRecord { };
            if (firstNameInput.Length == 0)
                firstNameInput = "Test";
                
            retrievedRecord.view(firstNameInput);
        }

        // First Name textbox
        private void TextBox_FirstName(object sender, TextChangedEventArgs e)
        {
            TextBox firstNameTextBox = (TextBox)sender;
            firstNameInput = firstNameTextBox.Text;
        }

        // Last Name textbox
        private void TextBox_LastName(object sender, TextChangedEventArgs e)
        {
            TextBox lastNameTextBox = (TextBox)sender;
            lastNameInput = lastNameTextBox.Text;
        }
    }
}
