﻿/*
 * Timothy Davis 
 * UW Oshkosh
 * CS 341
 * Veterans Department App
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace VeteransTrackerApp
{

	public partial class DownloadData : Window
	{
		public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";
		public string initialsInput = "";
		public string areaInput = "";
		public bool lab = false;
		public bool frontDesk = false;
		public bool lounge = false;
		public bool email = false;
		public bool phone = false;
		public SubmittedRecord submittedRecord;
		public RetrievedRecord retrievedRecord;
		public DateTime StartDate;
		public DateTime EndDate;

		public DownloadData()
		{
			InitializeComponent();
		}

		private void Check(object sender, RoutedEventArgs e)
		{
			CheckBox check = (CheckBox)sender;

			if ((string)check.Content == "Lab")
			{
				lab = true;
				if (areaInput.Length == 0)
					areaInput += "Lab ";
				else
					areaInput += ": Lab ";

			}

			else if ((string)check.Content == "Front Desk")
			{
				frontDesk = true;
				if (areaInput.Length == 0)
					areaInput += "FrontDesk ";
				else
					areaInput += ": FrontDesk ";
			}

			else if ((string)check.Content == "Lounge")
			{
				lounge = true;
				if (areaInput.Length == 0)
					areaInput += "Lounge ";
				else
					areaInput += ": Lounge ";
			}

			else if ((string)check.Content == "Email")
			{
				frontDesk = true;
				if (areaInput.Length == 0)
					areaInput += "Email ";
				else
					areaInput += ": Email ";
			}

			else if ((string)check.Content == "Phone")
			{
				lounge = true;
				if (areaInput.Length == 0)
					areaInput += "Phone ";
				else
					areaInput += ": Phone ";
			}
		}

		private void Dates()
		{
			DateTime startDate = new DateTime();
			DateTime endDate = new DateTime();

			TextBox startMonth = (TextBox)StartMonth;
			TextBox startYear = (TextBox)StartYear;
			TextBox endMonth = (TextBox)EndMonth;
			TextBox endYear = (TextBox)EndYear;

			startDate = Convert.ToDateTime("01/" + StartMonth + "/" + StartYear);
			endDate = Convert.ToDateTime("01/" + EndMonth + "/" + EndYear);
			StartDate = startDate;
			EndDate = endDate;
		}

		private void Gather(object sender, RoutedEventArgs e)
		{
			Button button = (Button)sender;

			Dates();

			retrievedRecord = new RetrievedRecord { };
			if (initialsInput.Length < 1)
				initialsInput = "Test";

			retrievedRecord.view(initialsInput);
		}
	}
}
