﻿
/*
 * Steven Richter + Timothy Davis
 * UW Oshkosh
 * CS 341
 * Veteran's Department App
 */

using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace VeteransTrackerApp
{
	public class RetrievedRecord : Record
	{
		public string connectionString = "Server=localhost;port=3306;user=team5;password=x287;database=team5";

		public void view(string inInitials)
		{
			MySqlConnection conn = null;
			MySqlCommand command = null;
			MySqlDataReader reader = null;

			try
			{
				conn = new MySqlConnection(connectionString);
				conn.Open();

				string strCommand = "SELECT * FROM `Records` WHERE initials='" + inInitials + "'";

				command = new MySqlCommand(strCommand, conn);
				MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

				reader = command.ExecuteReader();

				while (reader.Read())
				{

					Object initials = reader.GetValue(0);
					this.initials = initials.ToString();

					Object time = reader.GetValue(1);
					this.time = time.ToString();

					Object date = reader.GetValue(2);
					this.date = date.ToString();

					Object area = reader.GetValue(3);
					this.area = area.ToString();

					MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
				}
			}

			catch
			{
				MessageBox.Show("Failed");
			}
		}

		//This section made by Timothy, Gets the data from the MySQL based on Date and exports if it contains the correct area
		public void viewer(DateTime inDateS, DateTime inDateE, string inArea)
		{
			bool lab = findArea(inArea, "lab");
			bool desk = findArea(inArea, "desk");
			bool lounge = findArea(inArea, "lounge");
			bool email = findArea(inArea, "email");
			bool phone = findArea(inArea, "phone");
			MySqlConnection conn = null;
			MySqlCommand command = null;
			MySqlDataReader reader = null;

			try
			{
				conn = new MySqlConnection(connectionString);
				conn.Open();

				DateTime i = inDateS;
				while (!i.Equals(inDateS))
				{
					string strCommand = "SELECT * FROM `Records` WHERE date='" + i + "'";

					command = new MySqlCommand(strCommand, conn);
					MySqlDataAdapter MyAdapter = new MySqlDataAdapter();

					reader = command.ExecuteReader();

					while (reader.Read())
					{

						Object initials = reader.GetValue(0);
						this.initials = initials.ToString();

						Object time = reader.GetValue(1);
						this.time = time.ToString();

						Object date = reader.GetValue(2);
						this.date = date.ToString();

						Object area = reader.GetValue(3);
						this.area = area.ToString();
						if (lab || desk || lounge || email || phone)
						{
							string item = "" + this.initials + ", " + this.time + ", " + this.date + ", " + this.area;
							export(item);
						}

						MessageBox.Show(this.initials + ", " + this.time + ", " + this.date + ", " + this.area);
					}
				}
			}

			catch
			{
				MessageBox.Show("Failed");
			}
		}

		//This section made by Timothy, Checks if the area is in the requested area
		public bool findArea(string areas, string reqArea)
		{
			 return areas.ToLower().Contains(reqArea);
		}

		//This section made by Timothy, Creates or appends a file with todays date for an excel sheet to look up.
		public void export(string inString)
		{
			string date = DateTime.Today.ToString("mm/dd/yyyy");
			string path = @"c:\Users\Public\Desktop\" + date + ".csv";
			if (File.Exists(path))
			{
				using (StreamWriter sw = File.AppendText(path))
				{
					sw.WriteLine(inString);
				}
			}
			else if(!File.Exists(path))
			{
				using (StreamWriter sw = File.CreateText(path))
				{
					sw.WriteLine(inString);
				}
			}
		}
	}
}
